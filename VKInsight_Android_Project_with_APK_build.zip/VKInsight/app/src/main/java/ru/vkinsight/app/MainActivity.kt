package ru.vkinsight.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PersonSearch
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF101326)
private val Panel = Color(0xFF1B2038)
private val Violet = Color(0xFF8B7CFF)
private val Muted = Color(0xFFAEB4CF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VKInsightApp() }
    }
}

@Composable
fun VKInsightApp() {
    var tab by remember { mutableStateOf(0) }
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Violet, background = Ink, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 },
                        icon = { Icon(Icons.Default.PersonSearch, null) }, label = { Text("Профили") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 },
                        icon = { Icon(Icons.Default.Analytics, null) }, label = { Text("Аналитика") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 },
                        icon = { Icon(Icons.Default.Settings, null) }, label = { Text("О приложении") })
                }
            }
        ) { padding ->
            when (tab) {
                0 -> ProfilesScreen(Modifier.padding(padding))
                1 -> AnalyticsScreen(Modifier.padding(padding))
                else -> AboutScreen(Modifier.padding(padding))
            }
        }
    }
}

@Composable
fun Header() {
    Column(Modifier.fillMaxWidth().background(
        Brush.horizontalGradient(listOf(Color(0xFF302B63), Color(0xFF24243E)))
    ).padding(22.dp)) {
        Text("VK INSIGHT", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
        Spacer(Modifier.height(8.dp))
        Text("Публичная активность", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Без аккаунта • Без подписок • Бесплатно", color = Muted, fontSize = 13.sp)
    }
}

@Composable
fun ProfilesScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var profile by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(listOf<String>()) }
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 20.dp)) {
        item { Header() }
        item {
            Column(Modifier.padding(16.dp)) {
                Text("Открыть публичный профиль", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = profile, onValueChange = { profile = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Например: https://vk.com/club...") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Violet, unfocusedBorderColor = Muted,
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White
                    )
                )
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        val raw = profile.trim()
                        val url = if (raw.startsWith("http")) raw else "https://vk.com/$raw"
                        if (raw.isNotBlank()) {
                            saved = (saved + url).distinct()
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Открыть во ВКонтакте") }
                Spacer(Modifier.height(8.dp))
                Text("Приложение открывает только общедоступные страницы. Закрытые данные и скрытых посетителей оно не получает.",
                    color = Muted, fontSize = 12.sp)
            }
        }
        item { SectionTitle("Недавно открытые профили") }
        if (saved.isEmpty()) {
            item { EmptyCard("Здесь появятся профили, которые ты открывал из приложения.") }
        } else {
            items(saved.size) { index ->
                val url = saved[index]
                Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)
                    .clickable { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) },
                    colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Groups, null, tint = Violet)
                        Spacer(Modifier.width(10.dp))
                        Text(url, color = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
fun AnalyticsScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize()) {
        Header()
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Аналитика", fontSize = 23.sp, fontWeight = FontWeight.Bold)
            EmptyCard("Пока нет подтверждённых данных для статистики. VK Insight не будет придумывать гостей, просмотры или онлайн-статусы.")
            InfoCard("Что можно анализировать", "В будущих версиях — только данные, которые доступны публично и разрешены правилами платформы.")
            InfoCard("Важно", "Посещение страницы VK не раскрывает владельцу достоверный список гостей. Поэтому раздел не показывает вымышленные посещения.")
        }
    }
}

@Composable
fun AboutScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize()) {
        Header()
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("О VK Insight", fontSize = 23.sp, fontWeight = FontWeight.Bold)
            InfoCard("Бесплатно", "В приложении нет платных функций, подписок и рекламы.")
            InfoCard("Без авторизации", "Приложение не просит логин, пароль или токен VK.")
            InfoCard("Конфиденциальность", "Введённые адреса профилей хранятся только в памяти текущего запуска. Сетевой сбор скрытых данных не выполняется.")
            InfoCard("Версия", "MVP 1.0.0 • Android 8.0 и новее")
        }
    }
}

@Composable
fun SectionTitle(title: String) {
    Text(title, Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp),
        color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
}

@Composable
fun EmptyCard(message: String) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp),
        colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Info, null, tint = Violet)
            Spacer(Modifier.width(12.dp))
            Text(message, color = Muted, fontSize = 13.sp)
        }
    }
}

@Composable
fun InfoCard(title: String, body: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(5.dp))
            Text(body, color = Muted, fontSize = 13.sp)
        }
    }
}
